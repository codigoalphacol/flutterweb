var express = require('express');
const app = express();
app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    res.header("Access-Control-Allow-Methods", "GET, POST, OPTIONS, PUT, DELETE");
    if (req.method === 'OPTIONS') {
      return res.send(200);
      console.log('Dejo pasar Cors');
    } else {
      return next();
    }
  });

const { Router } = require('express');
const router = Router();




const productController = require('./productController')

router.route('/products')
    .get(productController.index)
    .post(productController.new)

router.route('/product/:id')
    .get(productController.view)
    .put(productController.update)
    .delete(productController.delete)


module.exports = router;